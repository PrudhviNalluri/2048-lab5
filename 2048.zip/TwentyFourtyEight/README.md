TwentyFortyEight
================

Personal clone of 2048. A native android version so i can play while offline. No copyright infringment intended, this is entirely a personal project. 
