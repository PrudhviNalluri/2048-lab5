package com.twofoureight.twentyfortyeightgame;

// oh for want of a struct...
public class Location {
	public int x;
	public int y;
	public int value;
	Location(int x, int y) {
		this.x = x;
		this.y = y;
		value = 0;
	}

}
